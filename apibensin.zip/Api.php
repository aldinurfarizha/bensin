<?php 

	require_once 'DbConnect.php';
	
	$response = array();
	
	if(isset($_GET['apicall'])){
		
		switch($_GET['apicall']){
			
			case 'ambil_data_trx':
				$stmt = $conn->prepare("SELECT id_transaksi,stand_meter,pembelian,penjualan,stock,  DATE_FORMAT(tanggal, '%d-%b-%Y') AS tanggal  FROM transaksi order by id_transaksi DESC");
				$stmt->execute();
				$stmt->store_result();
				$stmt->bind_result($id_transaksi, $stand_meter, $pembelian, $penjualan, $stock, $tanggal);
				$bobot= array(); 
				
				while($stmt->fetch()){
					$sales  = array();
					$sales['id_transaksi'] = $id_transaksi;
					$sales['stand_meter']= $stand_meter;
					$sales['pembelian']=$pembelian;
					$sales['penjualan']=$penjualan;
					$sales['stock']=$stock;
					$sales['tanggal']=$tanggal;

					array_push($bobot, $sales); 
				}
				
						
						$stmt->close();
						$response['data']= $bobot; 
		break; 

		case 'ambil_penjualan':
				
		
			$stmt = $conn->prepare("SELECT id_transaksi,penjualan FROM transaksi WHERE MONTH(tanggal) = MONTH(CURRENT_DATE()) AND YEAR(tanggal) = YEAR(CURRENT_DATE())");
			$stmt->execute();
			$stmt->store_result();
			$stmt->bind_result($id_transaksi,$penjualan);
			$bobot= array(); 
			
			while($stmt->fetch()){
				$sales  = array();
				$sales['id_transaksi'] = $id_transaksi;
				$sales['penjualan']= $penjualan;
				array_push($bobot, $sales); 
			}
			
					
					$stmt->close();
					$response['data']= $bobot; 
	break; 
				case 'ambil_bulanan':
				
		
			$stmt = $conn->prepare("SELECT sum(penjualan) as total_penjualan, sum(pembelian) as total_pembelian, DATE_FORMAT(tanggal, '%b-%Y') AS tanggal FROM transaksi GROUP BY MONTH(tanggal) DESC");
			$stmt->execute();
			$stmt->store_result();
			$stmt->bind_result($total_penjualan,$total_pembelian, $tanggal);
			$bobot= array(); 
			
			while($stmt->fetch()){
				$sales  = array();
				$sales['total_penjualan'] = $total_penjualan;
				$sales['total_pembelian']= $total_pembelian;
				$sales['tanggal']= $tanggal;
				
				array_push($bobot, $sales); 
			}
			
					
					$stmt->close();
					$response['data']= $bobot; 
	break;

	case 'ambil_pembelian':
				
		
		$stmt = $conn->prepare("SELECT id_transaksi,pembelian FROM transaksi WHERE MONTH(tanggal) = MONTH(CURRENT_DATE()) AND YEAR(tanggal) = YEAR(CURRENT_DATE())");
		$stmt->execute();
		$stmt->store_result();
		$stmt->bind_result($id_transaksi,$pembelian);
		$bobot= array(); 
		
		while($stmt->fetch()){
			$sales  = array();
			$sales['id_transaksi'] = $id_transaksi;
			$sales['pembelian']= $pembelian;
			array_push($bobot, $sales); 
		}
		
				
				$stmt->close();
				$response['data']= $bobot; 
break; 

			case 'ambil_data':
				
				
					$stmt = $conn->prepare("SELECT id_transaksi,stand_meter,pembelian,penjualan,stock FROM transaksi WHERE MONTH(tanggal) = MONTH(CURRENT_DATE()) AND YEAR(tanggal) = YEAR(CURRENT_DATE()) ORDER BY id_transaksi DESC LIMIT 1");
					$stmt->execute();
					$stmt->store_result();
					$stmt->bind_result($id_transaksi, $stand_meter, $pembelian, $penjualan, $stock);
					$bobot= array(); 
					
					while($stmt->fetch()){
						$sales  = array();
						$sales['id_transaksi'] = $id_transaksi;
						$sales['stand_meter']= $stand_meter;
						$sales['pembelian']=$pembelian;
						$sales['penjualan']=$penjualan;
						$sales['stock']=$stock;
						array_push($bobot, $sales); 
					}
					
							
							$stmt->close();
							$response['data']= $bobot; 
					
				
			break; 

			case 'ambil_jumlah':
				
				
				$stmt = $conn->prepare("SELECT sum(penjualan) as total_penjualan, sum(pembelian) as total_pembelian FROM transaksi WHERE MONTH(tanggal) = MONTH(CURRENT_DATE()) AND YEAR(tanggal) = YEAR(CURRENT_DATE())");
				$stmt->execute();
				$stmt->store_result();
				$stmt->bind_result($total_penjualan, $total_pembelian );
				$bobot= array(); 
				
				while($stmt->fetch()){
					$sales  = array();
					$sales['total_penjualan'] = $total_penjualan;
					$sales['total_pembelian']= $total_pembelian;
					array_push($bobot, $sales); 
				}
				
						
						$stmt->close();
						$response['data']= $bobot; 
				
			
		break;


		case 'posting':
				
			$stand_meter = $_POST['stand_meter'];
			$pembelian = $_POST['pembelian'];
			$penjualan = $_POST['penjualan'];
			$stock = $_POST['stock'];
			$tanggal = $_POST['tanggal'];

			$stmt = $conn->prepare("INSERT INTO transaksi (id_transaksi, stand_meter, pembelian, penjualan, stock, tanggal) values('',?,?,?,?,?)");
			$stmt->bind_param("sssss", $stand_meter, $pembelian, $penjualan, $stock, $tanggal);
		
						if($stmt->execute()){
							$response['error'] = false; 
							$response['message'] = 'Berhasil Di Posting'; 
						}
		
	break;

	case 'hapus':
				
		$id_transaksi = $_POST['id_transaksi'];
		$stmt = $conn->prepare("DELETE FROM transaksi WHERE id_transaksi=?");
		$stmt->bind_param("s", $id_transaksi);
	
					if($stmt->execute()){
						$response['error'] = false; 
						$response['message'] = 'Berhasil Di Hapus'; 
					}
	
break;
			
			
			default: 
				$response['error'] = true; 
				$response['message'] = 'Invalid Operation Called';
		}
		
	}else{
		$response['error'] = true; 
		$response['message'] = 'Invalid API Call';
	}
	
	echo json_encode($response);
	
	function isTheseParametersAvailable($params){
		
		foreach($params as $param){
			if(!isset($_POST[$param])){
				return false; 
			}
		}
		return true; 
	}