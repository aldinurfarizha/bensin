<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Chart</title>
</head>
<body class="html">
<canvas id="myChart"></canvas>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
    <script>
    var ctx = document.getElementById('myChart').getContext("2d")
var myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: [
            <?php 
require_once 'DbConnect.php';
$query=mysqli_query($conn,"SELECT MONTHNAME(tanggal) as bulan,sum(penjualan) as jumlah_penjualan, MONTH(tanggal)  FROM transaksi GROUP BY MONTHNAME(tanggal) ORDER BY MONTH(tanggal) ASC LIMIT 7");
$hasil=mysqli_num_rows($query);
while ($baris= mysqli_fetch_assoc($query)){
    echo '"'.$baris['bulan'].'",';
}
?>      ],
        datasets: [{
            label: "Data",
            borderColor: "#80b6f4",
            pointBorderColor: "#80b6f4",
            pointBackgroundColor: "#80b6f4",
            pointHoverBackgroundColor: "#80b6f4",
            pointHoverBorderColor: "#80b6f4",
            pointBorderWidth: 10,
            pointHoverRadius: 10,
            pointHoverBorderWidth: 1,
            pointRadius: 3,
            fill: false,
            borderWidth: 4,
            data: [
            <?php 
require_once 'DbConnect.php';
$query=mysqli_query($conn,"SELECT MONTHNAME(tanggal) as bulan,sum(penjualan) as jumlah_penjualan, MONTH(tanggal)  FROM transaksi GROUP BY MONTHNAME(tanggal) ORDER BY MONTH(tanggal) ASC LIMIT 7");
$hasil=mysqli_num_rows($query);
while ($baris= mysqli_fetch_assoc($query)){
    echo $baris['jumlah_penjualan'].',';
}
?>
            ]
        }]
    },
    options: {
        legend: {
            position: "bottom"
        },
        scales: {
            yAxes: [{
                ticks: {
                    fontColor: "rgba(0,0,0,0.5)",
                    fontStyle: "bold",
                    beginAtZero: true,
                    maxTicksLimit: 5,
                    padding: 20
                },
                gridLines: {
                    drawTicks: false,
                    display: false
                }
}],
            xAxes: [{
                gridLines: {
                    zeroLineColor: "transparent"
},
                ticks: {
                    padding: 20,
                    fontColor: "rgba(0,0,0,0.5)",
                    fontStyle: "bold"
                }
            }]
        }
    }
});
    </script>
</body>
</html>
